package com.cg.bank.service;

import java.util.List;

public interface TransactionService {
	void addTransaction(String msg, int num);

	List<String> getTransaction(int id);
}

package com.cg.bank.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.bank.bean.Customer;
import com.cg.bank.dao.CustomDao;
import com.cg.bank.exception.CustomException;




@Service
public class CustomServiceImpl implements CustomService{
	@Autowired
CustomDao customDao;
	@Override
	public boolean addCustomer(Customer cust) throws CustomException {
		// TODO Auto-generated method stub
		try {
			customDao.save(cust);
		return	true;
		}
		catch(Exception ex)
		{
			throw new CustomException("Please enter the details Properly");
		}
		
	}

	@Override
	public int loginByUsername(String username, String password) throws CustomException {
		// TODO Auto-generated method stub
		try {
		Customer cust=customDao.getCustomerByUsername(username);
		  if(cust.getPassword().equals(password))
		        return cust.getAccountNo();
		        else
		        {
		            throw new CustomException("Please enter valid username and password");
		       
		        }
		        }
		        catch(Exception ex)
		        {
		            throw new CustomException("Please enter valid username and password");
		        }
	}
	@Override
	public double deposit(int accountNo, double amount) throws CustomException {
		// TODO Auto-generated method stub
		try{
			Customer cust=customDao.getCustomerByAccountNo(accountNo);
		
		double Bal=cust.getBalance()+amount;
		cust.setBalance(Bal);
		customDao.save(cust);
	     return cust.getBalance();
		}
		catch(Exception ex)
		{
			throw new CustomException("Please enter valid account number");
		}
		
	}

	@Override
	public double withdraw(int accountNo, double amount) throws CustomException {
		// TODO Auto-generated method stub
		try
		{
		Customer cust=customDao.getCustomerByAccountNo(accountNo);
		double remBal=cust.getBalance()-amount;
		 cust.setBalance(remBal);
		 customDao.save(cust);
		return cust.getBalance();
		}
		catch(Exception ex)
		{
			throw new CustomException("Please enter valid account number");
		}
	}

	@Override
	public double showBalance(int accountNo) throws CustomException {
		// TODO Auto-generated method stub
		try
		{
		Customer cust=customDao.getCustomerByAccountNo(accountNo);
		return cust.getBalance();
		}
		catch(Exception ex)
		{
			throw new CustomException("Invalid account number");
		}
		
	}

	@Override
	public String fundTransfer(int accountNo1, int accountNo2, double amount) throws CustomException {
		// TODO Auto-generated method stub
		
		try {
			Customer cust1=customDao.getCustomerByAccountNo(accountNo1);
			double remBal1=(cust1.getBalance()-amount);
			cust1.setBalance(remBal1);
			customDao.save(cust1);
			Customer cust2=customDao.getCustomerByAccountNo(accountNo2);
			double remBal2=cust2.getBalance()+amount;
			cust2.setBalance(remBal2);
			customDao.save(cust2);
			return "Amount transfered successfully";
			}
			catch(Exception ex)
			{
				throw new CustomException("Please enter valid account");
			}
	}

	@Override
	public Customer getCustomerDetails(int accountNo) throws CustomException {
		// TODO Auto-generated method stub
		try
		{
		return customDao.getCustomerByAccountNo(accountNo);
		}
		catch(Exception ex)
		{
			throw new CustomException("Please enter valid account number");
		}
		
	}

}

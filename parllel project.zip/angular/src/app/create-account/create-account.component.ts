import { Component, OnInit } from '@angular/core';
import { BankServiceService } from '../bank-service.service';
import { Customer } from '../customer';
import { Router } from '@angular/router';

@Component({
  selector: 'app-create-account',
  templateUrl: './create-account.component.html',
  styleUrls: ['./create-account.component.css']
})
export class CreateAccountComponent implements OnInit {
  cust : Customer;
  constructor(private router: Router, private userService:BankServiceService) { 
    this.cust=new Customer();
  }
  
  ngOnInit() {
 
  }

onSubmit(cust: Customer)
{
  this.userService.addCustomer(this.cust).subscribe(result=>{
    console.log(result);
    this.gotoCustomer();
  });
}
gotoCustomer()
{
  this.router.navigate(['/homecomponent']);
}

newCustomer(name,email,password,username,addhar,mobile,balance){
  this.cust.firstName=name;
  this.cust.emailId=email;
  this.cust.password=password;
  this.cust.username =username;
  this.cust.aadharNo=addhar;
  this.cust.mobileNo=mobile;
  this.cust.balance=balance;
this.onSubmit(this.cust);
}
}

import { Injectable } from '@angular/core';
import { Customer } from './customer';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})


export class BankServiceService {
  
accountnum:number;

  constructor(private httpClient:HttpClient) { 
    
  }
  addCustomer(cust :Customer ): Observable<boolean>
  {
  return this.httpClient.post<boolean>('http://localhost:9050/customer',cust);
  }
  login(username, password): Observable<number>
  {
    let url = 'http://localhost:9050/login/'+username+'/'+password;
    
    return this.httpClient.get<number>(url);
    }
    showbalance():Observable<number>
    {
      let url = 'http://localhost:9050/showbal/'+this.accountnum;
      
      return this.httpClient.get<number>(url);
      }
      deposit(amount):Observable<number>
      {
        let url = 'http://localhost:9050/deposit/'+this.accountnum+'/'+amount;
        return this.httpClient.put<number>(url,"");
        }
        withdraw(amount)
        {
          let url = 'http://localhost:9050/withdrawl/'+this.accountnum+'/'+amount;
          return this.httpClient.put<number>(url,""); 
        }
        fundTransfer(destination: string,amount: string):Observable<string>
        {
          let url = 'http://localhost:9050/Transfer/'+this.accountnum+'/'+destination+'/'+amount;
          return this.httpClient.put<string>(url,""); 
        }

        getTransactionsByAccountNo():Observable<string[]>{
          let url = 'http://localhost:9050/getTransactions/all/'+this.accountnum;
          console.log(url);
          return this.httpClient.get<string[]>(url);
          }
 getAccountNumber(){
    return this.accountnum;
  }

  setAccountNumber(accno:number){
    this.accountnum=accno;
  }
}

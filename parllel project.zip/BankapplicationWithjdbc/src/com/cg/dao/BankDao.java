package com.cg.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.cg.bean.CustomerDetails;
import com.cg.dbutil.DbUtil;



public class BankDao {
	private Connection connection;
	PreparedStatement prepStmt ;
	double accountBal;
	double accountBal1;

	
	public CustomerDetails save(CustomerDetails c) {
		
		connection = DbUtil.getConnection();
		try {
			prepStmt = connection.prepareStatement("insert into CustomerDetails values(?,?,?,?,?,?)");
			prepStmt.setString(1, c.getFname());
			prepStmt.setString(2, c.getLname());
			prepStmt.setLong(3, c.getPhnum());
			prepStmt.setLong(4, c.getAadharnum());
			prepStmt.setLong(5, c.setAcountnum());
			prepStmt.setDouble(6, c.getMoney());
			int i = prepStmt.executeUpdate();
			if(i>0)
			{
				System.out.println("Your Account number is:"+c.getAccountnum());
				System.out.println("Account is Successfully created!!!!");
			}
		}
		catch(SQLException e1)
		{
			System.err.println("Something went wrong");
			e1.printStackTrace();
		}
		return null;
	}

	public String showBal(long accnum) {
		PreparedStatement prepStmt;
		connection = DbUtil.getConnection();
		ResultSet rs;
		CustomerDetails c = new CustomerDetails();
		try {
			prepStmt = connection.prepareStatement("select money from CustomerDetails where accountnum = ?");
			prepStmt.setLong(1, accnum);
			rs = prepStmt.executeQuery();
			if(Long.toString(rs.getLong(1)) != null) {
			while(rs.next())
			{
				try {
				return Long.toString(rs.getLong(1));
				}
				catch(SQLException e1)
				{
					e1.printStackTrace();
				}
			}
		}
			else {
				System.out.println("Account Number Does Not Exists!!!!");
				System.out.println("please create the account first!!");
			}
		}
		catch(SQLException e1)
		{
			System.out.println("No such Account Number");
			e1.printStackTrace();
		}	
		return Double.toString(c.getMoney());
	}

	
	public void deposit(long acnum, double money1) {
		
		
		connection = DbUtil.getConnection();
		try {
			prepStmt = connection.prepareStatement("select money from CustomerDetails where accountnum = ?");
			prepStmt.setLong(1, acnum);
			ResultSet rs = prepStmt.executeQuery();
			if(Long.toString(rs.getLong(1)) != null) {
			while(rs.next())
			{
				accountBal = rs.getDouble(1);
				prepStmt = connection.prepareStatement("update CustomerDetails set money = ? where accountnum = ?");
				prepStmt.setDouble(1, accountBal+money1);
				prepStmt.setLong(2, acnum);
					int i =prepStmt.executeUpdate();
					if(i>0)
					{
						System.out.println("Your Current Balance is: "+(accountBal+money1));
					}				
			}
		} 
			else {
				System.out.println("Account Number Does Not Exists!!!!");
				System.out.println("please create the account first!!");
			}
		}
		catch (SQLException e) {
			e.printStackTrace();
		}
	}


	public void withdraw(long acnum1, double money) {
		connection = DbUtil.getConnection();
		try {
			prepStmt = connection.prepareStatement("select money from CustomerDetails where accountnum = ?");
			prepStmt.setLong(1, acnum1);
			ResultSet rs = prepStmt.executeQuery();
			while(rs.next())
			{
				accountBal = rs.getDouble(1);
				if(accountBal>=money)
				{
					prepStmt = connection.prepareStatement("update CustomerDetails set money = ? where accountnum = ?");
					prepStmt.setDouble(1, accountBal-money);
					prepStmt.setLong(2, acnum1);
					int i = prepStmt.executeUpdate();
					if(i>0)
					{
						System.out.println("Your Current Balance is: "+(accountBal-money));
					}
				}
				
			}
		} 
		catch (SQLException e) {
			e.printStackTrace();
		}
		
	}


	public double transfer(long yaccnum, long raccnum, long amt) {
		connection = DbUtil.getConnection();
		try {
			prepStmt = connection.prepareStatement("select money from CustomerDetails where accountnum = ?");
			prepStmt.setLong(1, yaccnum);
			PreparedStatement prepStmt2 = connection.prepareStatement("select money from CustomerDetails where accountnum = ?");
			prepStmt2.setLong(1, raccnum);
			ResultSet rs = prepStmt.executeQuery();
			ResultSet rs1 = prepStmt2.executeQuery();
			while(rs.next()&&rs1.next())
			{
				accountBal1=rs1.getDouble(1);
				accountBal = rs.getDouble(1);
				if(accountBal >= amt)
				{
					prepStmt = connection.prepareStatement("update CustomerDetails set money = ? where accountnum = ?");
					prepStmt.setDouble(1, accountBal-amt);
					prepStmt.setLong(2, yaccnum);
					PreparedStatement prepStmt1 = connection.prepareStatement("update CustomerDetails set money = ? where accountnum = ?");
					prepStmt1.setDouble(1, accountBal1+amt);
					prepStmt1.setLong(2, raccnum);
					prepStmt1.executeUpdate();
					int i = prepStmt.executeUpdate();
					if(i>0)
					{
						return accountBal-amt;
					}
				}
			}
		} 
		catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return -1;
	}	

}

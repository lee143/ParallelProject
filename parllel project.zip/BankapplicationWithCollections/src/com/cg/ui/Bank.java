 package com.cg.ui;
import java.util.Arrays;
import java.util.Scanner;
import com.cg.bean.BankBean;
import com.cg.service.BankService;
public class Bank {
	BankService bankServiceObj = new BankService();
	Scanner sc = new Scanner(System.in);
	
	
	public void createAccount() 
	{
	System.out.print("Enter Name: ");
	String name = sc.next();
	System.out.print("Enter Mobile No.: ");
	long mobNo = sc.nextLong();
	long accNo=(long) ((Math.random() * ((9999999 - 999) + 1)) + 999); 
	BankBean bankBeanObjCreateAccountObj = new BankBean(accNo, name, mobNo);
	System.out.println("Account Is created with Account Number: " +accNo);
	bankServiceObj.bankAccountCreate(bankBeanObjCreateAccountObj);
	}
	
	
	public void showBalance()
	{
	System.out.print("Enter Account Number: ");
	long accNo = sc.nextLong();
	BankBean bankBeanShowBalObj = new BankBean(accNo);
	bankServiceObj.showBalanceSer(bankBeanShowBalObj);
	}
	
	
	public void deposit()
	{
	System.out.print("Enter Account Number: ");
	long accNo = sc.nextLong();
	System.out.print("Enter Deposit Amount: ");
	float depAmount = sc.nextFloat();
	BankBean bankBeanDeptObj = new BankBean(accNo, depAmount);
	bankServiceObj.depositSer(bankBeanDeptObj);
	}
	
	
	public void withdraw() 
	{
	System.out.print("Enter Account Number: ");
	long accNo = sc.nextLong();
	System.out.print("Enter Withdraw Amount: ");
	float withdrawAmount = sc.nextFloat();
	BankBean bankBeanWithdrawObj = new BankBean(withdrawAmount, accNo);
	bankServiceObj.withdrawSer(bankBeanWithdrawObj);
	}
	
	
	public void fundTransfer() 
	{ 
	System.out.println("Enter Source Account Number: ");
	long sourceAccNo = sc.nextLong();
	System.out.println("Enter Destination Account Number: ");
	long destAccNo = sc.nextLong();
	System.out.println("Enter Amount to transfer: "); 
	float transferAmount = sc.nextFloat();
	BankBean bankBeanFundTransObj = new BankBean(sourceAccNo, destAccNo, transferAmount);
	bankServiceObj.transferSer(bankBeanFundTransObj);
	String transactions = transferAmount+ " transferred from Account number " +sourceAccNo+ " to " +destAccNo;
	bankBeanFundTransObj = new BankBean(transactions);
	}
	
	
	public void printTransactions()
	{
	System.out.println(Arrays.toString(BankBean.transactions));
	}

}
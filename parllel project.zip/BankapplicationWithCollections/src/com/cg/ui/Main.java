package com.cg.ui;
import java.util.Scanner;
public class Main {  
	public static void main(String args[]) 
	{
	int ch;
	Bank bank = new Bank();
	Scanner sc = new Scanner(System.in);
	while(true){
	System.out.println("\n ------------------\n 1. Create Account \n 2. Show Balance \n 3. Deposit \n 4. Withdraw \n 5. Fund Transfer \n 6. Print Transactions \n 7. Exit\n------------------------");
	System.out.print("Enter your choice : ");
	ch = sc.nextInt(); 
	switch(ch) {
	case 1:
	bank.createAccount(); 
	break;
	case 2: 
	bank.showBalance(); 
	break;
	case 3: 
	bank.deposit();
	break;
	case 4:
	bank.withdraw();
	break;
	case 5: 
	bank.fundTransfer();
	break;
	case 6:
	bank.printTransactions();
	break;
	case 7:
		System.out.println("Thank You !");
	    System.exit(0);
	    break;
	
	}
}
	}
}